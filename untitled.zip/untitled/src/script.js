const oui = document.getElementById("oui");
const container = document.getElementById("container");
const video = document.getElementById("video");

// Position initiale
oui.style.left = "45%";
oui.style.top = "100px";

// Bouton qui fuit
oui.addEventListener("touchstart", bouger);
oui.addEventListener("mouseover", bouger);

function bouger() {

    const maxX = container.clientWidth - oui.offsetWidth;
    const maxY = container.clientHeight - oui.offsetHeight;

    const x = Math.random() * maxX;
    const y = Math.random() * maxY;

    oui.style.left = x + "px";
    oui.style.top = y + "px";
}

// Si on clique
oui.addEventListener("click", () => {
    video.style.display = "block";
});